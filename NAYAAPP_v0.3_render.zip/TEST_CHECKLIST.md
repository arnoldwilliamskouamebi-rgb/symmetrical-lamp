# Checklist de tests manuels NAYAAPP v0.2

- [ ] `GET http://localhost:4000/health` répond `{"status":"ok"}`.
- [ ] Inscription avec données valides crée un compte et une organisation.
- [ ] Un e-mail déjà utilisé renvoie une erreur 409.
- [ ] Connexion avec mot de passe correct retourne un jeton.
- [ ] Connexion avec mauvais mot de passe est refusée.
- [ ] `/auth/me` refuse une requête sans jeton.
- [ ] `/apps` refuse une requête sans jeton.
- [ ] Création d'application connectée persiste après déconnexion/reconnexion.
- [ ] Un utilisateur d'une autre organisation ne peut pas lire une application privée.
- [ ] Le frontend affiche un message clair lorsque l'API est hors ligne.
