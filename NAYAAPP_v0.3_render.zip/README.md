# NAYAAPP v0.2 — prototype connecté (développement local)

Cette version rassemble le studio web v0.1 et l'API Node.js/Express + PostgreSQL v0.1.

## Ce qui est relié
- Écran de connexion et création de compte.
- Création automatique d'un espace organisation lors de l'inscription.
- Vérification de session JWT.
- Liste et création des applications via l'API.
- Les applications sont stockées dans PostgreSQL, pas seulement dans le navigateur.
- Interface FR/EN conservée.

## Démarrage
Prérequis : Node.js 20+, npm et Docker Desktop.

1. Décompresser l'archive.
2. Dans le dossier racine, copier `.env.example` vers `.env`.
3. Remplacer `JWT_SECRET` par une clé privée aléatoire de 32 caractères minimum.
4. Démarrer PostgreSQL : `docker compose up -d`
5. Installer l'API : `npm install`
6. Créer les tables : `npm run migrate`
7. Démarrer l'API : `npm run dev`
8. Dans un autre terminal, servir le dossier frontend depuis localhost, par exemple :
   `npx http-server frontend -p 8080`
9. Ouvrir `http://localhost:8080`.

L'URL de l'API est configurée dans `frontend/config.js` (par défaut `http://localhost:4000/api/v1`).

## Parcours de test
1. Cliquer sur « Créer un compte ».
2. Entrer un nom, un e-mail de test, un mot de passe de 10 caractères minimum et un nom d'organisation.
3. Après connexion, créer une application depuis le tableau de bord.
4. Se déconnecter puis se reconnecter : l'application doit réapparaître depuis PostgreSQL.

## Routes API
- `GET /health`
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/apps`
- `POST /api/v1/apps`
- `GET /api/v1/apps/:id`

## Limites connues
- Cette version est un prototype local et n'a pas encore subi de tests d'intégration exécutés dans un environnement réel.
- Les modifications avancées des applications, pages/sections, téléversement de médias, formulaires, notifications, rôles d'équipe et statistiques réelles restent à développer.
- La récupération et vérification d'e-mail, révocation/rotation des jetons, journal d'audit, sauvegardes automatisées, tests de sécurité et déploiement HTTPS restent nécessaires avant production.
- Le navigateur conserve le jeton JWT dans localStorage pour simplifier ce prototype. Pour la production, préférer une stratégie de session sécurisée adaptée (cookies HttpOnly/SameSite, protection CSRF, etc.).
- Les graphiques et certaines données visuelles restent des démonstrations.

Ne mettez jamais de vrais mots de passe dans les captures d'écran ou les messages. Ne partagez jamais le fichier `.env`.


## Démarrage depuis Android (Replit)
Consulter `DEPLOY_RENDER.md` (Render + Neon, gratuit). Cette archive sert maintenant le frontend et l'API sur la même origine ; `frontend/config.js` utilise `/api/v1` au lieu de `localhost`. Il faut tout de même fournir une base PostgreSQL hébergée via `DATABASE_URL` et un `JWT_SECRET` privé dans les Secrets de l'environnement.
