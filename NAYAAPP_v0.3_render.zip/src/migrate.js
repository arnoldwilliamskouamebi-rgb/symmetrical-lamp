import "dotenv/config";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { pool } from "./db.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const migration = await fs.readFile(path.join(here, "../db/migrations/001_initial.sql"), "utf8");

try {
  await pool.query(migration);
  console.log("Migration 001 exécutée avec succès.");
} catch (error) {
  console.error("Échec migration:", error.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
