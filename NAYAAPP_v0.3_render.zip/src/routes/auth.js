import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { pool } from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
const registerSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(254),
  password: z.string().min(10).max(72),
  organizationName: z.string().trim().min(2).max(160)
});
const loginSchema = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(72)
});

router.post("/register", async (req, res, next) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Données invalides.", details: parsed.error.flatten() });

  const { fullName, email, password, organizationName } = parsed.data;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const passwordHash = await bcrypt.hash(password, 12);
    const userResult = await client.query(
      "INSERT INTO users (full_name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, full_name, email",
      [fullName, email.toLowerCase(), passwordHash]
    );
    const user = userResult.rows[0];
    const orgResult = await client.query(
      "INSERT INTO organizations (name, owner_id) VALUES ($1, $2) RETURNING id, name",
      [organizationName, user.id]
    );
    const org = orgResult.rows[0];
    await client.query(
      "INSERT INTO organization_members (organization_id, user_id, role) VALUES ($1, $2, 'owner')",
      [org.id, user.id]
    );
    await client.query("COMMIT");
    const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "2h" });
    res.status(201).json({ user, organization: org, token });
  } catch (error) {
    await client.query("ROLLBACK");
    if (error.code === "23505") return res.status(409).json({ error: "Cette adresse e-mail est déjà utilisée." });
    next(error);
  } finally {
    client.release();
  }
});

router.post("/login", async (req, res, next) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "E-mail ou mot de passe invalide." });
  try {
    const result = await pool.query(
      "SELECT id, full_name, email, password_hash FROM users WHERE email = $1",
      [parsed.data.email.toLowerCase()]
    );
    const user = result.rows[0];
    const valid = user && await bcrypt.compare(parsed.data.password, user.password_hash);
    if (!valid) return res.status(401).json({ error: "E-mail ou mot de passe incorrect." });
    const token = jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "2h" });
    res.json({ user: { id: user.id, full_name: user.full_name, email: user.email }, token });
  } catch (error) { next(error); }
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.full_name, u.email, o.id AS organization_id, o.name AS organization_name, om.role
       FROM users u
       JOIN organization_members om ON om.user_id = u.id
       JOIN organizations o ON o.id = om.organization_id
       WHERE u.id = $1 ORDER BY o.created_at LIMIT 1`,
      [req.user.sub]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Compte introuvable." });
    res.json({ profile: result.rows[0] });
  } catch (error) { next(error); }
});

export default router;
