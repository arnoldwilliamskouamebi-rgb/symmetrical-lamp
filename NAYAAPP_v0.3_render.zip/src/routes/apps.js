import { Router } from "express";
import { z } from "zod";
import { pool } from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
router.use(requireAuth);

const appSchema = z.object({
  name: z.string().trim().min(2).max(160),
  description: z.string().max(4000).optional().default(""),
  primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional().default("#2563eb")
});

router.get("/", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT a.id, a.name, a.description, a.primary_color, a.status, a.created_at, a.updated_at
       FROM applications a
       JOIN organization_members om ON om.organization_id = a.organization_id
       WHERE om.user_id = $1 ORDER BY a.created_at DESC`,
      [req.user.sub]
    );
    res.json({ applications: result.rows });
  } catch (error) { next(error); }
});

router.post("/", async (req, res, next) => {
  const parsed = appSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Données invalides.", details: parsed.error.flatten() });
  try {
    const membership = await pool.query(
      "SELECT organization_id FROM organization_members WHERE user_id = $1 ORDER BY created_at LIMIT 1",
      [req.user.sub]
    );
    if (!membership.rowCount) return res.status(403).json({ error: "Aucune organisation associée." });
    const { name, description, primaryColor } = parsed.data;
    const result = await pool.query(
      `INSERT INTO applications (organization_id, name, description, primary_color)
       VALUES ($1, $2, $3, $4)
       RETURNING id, organization_id, name, description, primary_color, status, created_at`,
      [membership.rows[0].organization_id, name, description, primaryColor]
    );
    res.status(201).json({ application: result.rows[0] });
  } catch (error) { next(error); }
});

router.get("/:id", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT a.id, a.organization_id, a.name, a.description, a.primary_color, a.status, a.created_at, a.updated_at
       FROM applications a JOIN organization_members om ON om.organization_id = a.organization_id
       WHERE a.id = $1 AND om.user_id = $2`,
      [req.params.id, req.user.sub]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Application introuvable." });
    res.json({ application: result.rows[0] });
  } catch (error) { next(error); }
});

export default router;
