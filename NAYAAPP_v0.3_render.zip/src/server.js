import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import authRoutes from "./routes/auth.js";
import appRoutes from "./routes/apps.js";

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error("JWT_SECRET doit contenir au moins 32 caractères. Configurez votre fichier .env.");
}
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL est obligatoire.");

const app = express();
app.set("trust proxy", 1); // derrière le proxy de Render
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const frontendDir = path.resolve(__dirname, "../frontend");
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",") || false }));
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ status: "ok", service: "nayaapp-api" }));
app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/apps", appRoutes);

app.use(express.static(frontendDir));
app.get("/", (_req, res) => res.sendFile(path.join(frontendDir, "index.html")));
app.use((req, res) => res.status(404).json({ error: "Route introuvable." }));
app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: "Une erreur interne est survenue." });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`NAYAAPP API démarrée sur http://localhost:${port}`));
