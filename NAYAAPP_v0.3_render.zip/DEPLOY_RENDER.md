# Déployer NAYAAPP gratuitement (Render + Neon) depuis Android

1. **GitHub** : créez un dépôt privé et envoyez-y tout le contenu du zip (sans `.env`, ni `node_modules`).
2. **Neon** (neon.com) : créez un projet, puis copiez l'URL de connexion PostgreSQL. Elle doit finir par `?sslmode=require`.
3. **Render** (render.com) : New > Blueprint (ou Web Service), choisissez votre dépôt. `render.yaml` configure tout, plan Free.
4. Quand Render demande `DATABASE_URL`, collez l'URL Neon. `JWT_SECRET` est généré automatiquement.
5. Déployez. La migration de la base s'exécute à chaque démarrage (elle est sans danger, `IF NOT EXISTS`).
6. Ouvrez `https://<votre-service>.onrender.com/health` : vous devez voir `{"status":"ok"}`. Puis ouvrez la racine du site et créez un compte de test.

Limites du gratuit : le service s'endort après 15 min d'inactivité (réveil ~1 min) et la base Neon après 5 min. Prototype uniquement.
