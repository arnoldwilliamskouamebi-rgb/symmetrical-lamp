// Même origine : le navigateur Android accède à l’API et à l’interface via la même URL.
window.NAYA_CONFIG = {
  API_BASE_URL: "/api/v1"
};
