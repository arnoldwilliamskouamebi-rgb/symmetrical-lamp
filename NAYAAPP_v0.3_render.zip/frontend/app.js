const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const translations={
fr:{workspace:"Espace de travail",dashboard:"Tableau de bord",myapps:"Mes applications",builder:"Constructeur",analytics:"Statistiques",savedlocally:"Enregistré sur cet appareil",overview:"VUE D'ENSEMBLE",hello:"Bonjour, bienvenue sur NAYAAPP.",intro:"Créez et gérez les expériences numériques de vos entreprises depuis un seul endroit.",newapp:"Nouvelle application",totalapps:"Applications créées",published:"Applications publiées",interactions:"Interactions de démonstration",allworkspaces:"Dans cet espace de travail",readyusers:"Prêtes pour les utilisateurs",sampledata:"Données de démonstration",recentapps:"Applications récentes",manageapps:"Gérez vos projets depuis cette page.",viewall:"Voir tout →",tiptitle:"Un bon départ pour votre première application",tiptext:"Choisissez un modèle, ajoutez vos informations et prévisualisez votre application avant de la publier.",start:"Commencer →",workspaceapps:"ESPACE DE TRAVAIL",appsdesc:"Toutes vos applications au même endroit.",creationstudio:"STUDIO DE CRÉATION",builderdesc:"Configurez une première expérience mobile en quelques étapes.",save:"Enregistrer",appdetails:"Informations de l'application",appname:"Nom de l'application",category:"Secteur d'activité",description:"Description",brandcolor:"Couleur principale",homepagecontent:"Contenu de la page d'accueil",welcometitle:"Titre d'accueil",welcometext:"Texte de présentation",savepreview:"Enregistrer et actualiser l'aperçu",livepreview:"APERÇU EN DIRECT",previewnote:"Aperçu de démonstration — le déploiement mobile sera une étape ultérieure.",analyticsdesc:"Vue de démonstration de l'activité de votre espace.",activity:"Activité récente",analyticsnote:"Les graphiques utilisent des données fictives dans cette première version.",needhelp:"Besoin d'aide ?",helptext:"Consultez le guide de démarrage",createfirst:"Créer une application",modaldesc:"Donnez un nom à votre nouveau projet. Vous pourrez tout personnaliser ensuite.",create:"Créer mon application",footer:"Prototype fonctionnel • Version 0.1"},
en:{workspace:"Workspace",dashboard:"Dashboard",myapps:"My applications",builder:"App builder",analytics:"Analytics",savedlocally:"Saved on this device",overview:"OVERVIEW",hello:"Hello, welcome to NAYAAPP.",intro:"Create and manage your businesses' digital experiences from one place.",newapp:"New application",totalapps:"Applications created",published:"Published applications",interactions:"Demo interactions",allworkspaces:"In this workspace",readyusers:"Ready for users",sampledata:"Demo data",recentapps:"Recent applications",manageapps:"Manage your projects from this page.",viewall:"View all →",tiptitle:"A great start for your first app",tiptext:"Choose a template, add your information and preview your app before publishing.",start:"Get started →",workspaceapps:"WORKSPACE",appsdesc:"All your applications in one place.",creationstudio:"CREATION STUDIO",builderdesc:"Set up your first mobile experience in a few steps.",save:"Save",appdetails:"Application details",appname:"Application name",category:"Business category",description:"Description",brandcolor:"Brand color",homepagecontent:"Home page content",welcometitle:"Welcome headline",welcometext:"Introduction text",savepreview:"Save and refresh preview",livepreview:"LIVE PREVIEW",previewnote:"Demo preview — mobile deployment will be a later step.",analyticsdesc:"Demo view of your workspace activity.",activity:"Recent activity",analyticsnote:"Charts use sample data in this first version.",needhelp:"Need help?",helptext:"Read the getting started guide",createfirst:"Create an application",modaldesc:"Name your new project. You can customize everything later.",create:"Create my application",footer:"Functional prototype • Version 0.1"}
};
let lang="fr", color="#5b5ce2", editingId=null, authMode="login", apiMode=false;
const defaultApps=[{id:"demo-1",name:"NAYA Démo",category:"Services",description:"Votre première application de démonstration.",status:"draft",updated:Date.now()}];
let apps=JSON.parse(localStorage.getItem("naya_apps")||"null")||defaultApps;
function save(){if(!apiMode)localStorage.setItem("naya_apps",JSON.stringify(apps));renderApps()}
function t(k){return translations[lang][k]||k}
function toast(msg){let el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function renderApps(){let html=apps.map(a=>`<article class="app-card" data-id="${a.id}"><div class="app-card-head"><div class="app-logo">${a.name.trim().charAt(0).toUpperCase()}</div><span class="pill ${a.status==="published"?"live":""}">${a.status==="published"?(lang==="fr"?"Publiée":"Published"):(lang==="fr"?"Brouillon":"Draft")}</span></div><h3>${escapeHtml(a.name)}</h3><p>${escapeHtml(a.category)} · ${escapeHtml(a.description||"")}</p><div class="card-foot"><span>${lang==="fr"?"Modifiée":"Updated"} ${new Date(a.updated).toLocaleDateString()}</span><span>•••</span></div></article>`).join("");
$("#recentGrid").innerHTML=html||emptyState();$("#allGrid").innerHTML=html||emptyState();$("#appCount").textContent=apps.length;$("#publishedCount").textContent=apps.filter(a=>a.status==="published").length;$$(".app-card").forEach(c=>c.addEventListener("click",()=>{let a=apps.find(x=>x.id===c.dataset.id);loadBuilder(a);showView("builder")}))
}
function emptyState(){return `<div class="panel"><b>${lang==="fr"?"Aucune application pour le moment":"No applications yet"}</b><p class="muted">${lang==="fr"?"Créez votre première application.":"Create your first application."}</p></div>`}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showView(v){$$(".view").forEach(x=>x.classList.add("hidden"));$("#"+v).classList.remove("hidden");$$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===v));$("#crumbTitle").textContent=t(v==="apps"?"myapps":v);if(v==="builder")updatePreview()}
function loadBuilder(a){editingId=a?.id||null;$("#appName").value=a?.name||"Ma première application";$("#appCategory").value=a?.category||"Commerce";$("#appDescription").value=a?.description||"";$("#welcomeTitle").value=a?.welcomeTitle||"Tout commence ici";$("#welcomeText").value=a?.welcomeText||"Découvrez nos actualités, nos services et toutes nos informations.";color=a?.color||"#5b5ce2";$("#customColor").value=color;updatePreview()}
function updatePreview(){let name=$("#appName").value||"NAYAAPP";$("#previewBrand").textContent=name;$("#previewTitle").textContent=$("#welcomeTitle").value;$("#previewText").textContent=$("#welcomeText").value;$(".hero-preview").style.background=color;$(".hero-preview button").style.color=color}
async function saveBuilder(){
  let name=$("#appName").value.trim();
  if(!name){toast(lang==="fr"?"Ajoutez un nom d'application.":"Enter an app name.");return}
  const payload={name,description:$("#appDescription").value,primaryColor:color};
  try{
    if(apiMode){
      if(editingId){toast(lang==="fr"?"La modification complète sera ajoutée dans la prochaine version.":"Full editing will be added in the next version.");return}
      const data=await NayaAPI.createApp(payload);
      apps.unshift({...data.application,category:$("#appCategory").value,updated:Date.now()});
      editingId=data.application.id;
    }else{
      let obj={id:editingId||crypto.randomUUID(),name,category:$("#appCategory").value,description:payload.description,status:"draft",welcomeTitle:$("#welcomeTitle").value,welcomeText:$("#welcomeText").value,color,updated:Date.now()};
      let idx=apps.findIndex(a=>a.id===obj.id);if(idx>=0)apps[idx]=obj;else apps.unshift(obj);
    }
    save();updatePreview();toast(lang==="fr"?"Application enregistrée !":"Application saved!");
  }catch(e){toast(e.message)}
}
function openModal(){$("#modal").classList.remove("hidden");$("#newName").focus()}
async function createApp(){
  let name=$("#newName").value.trim();
  if(!name){toast(lang==="fr"?"Saisissez un nom.":"Please enter a name.");return}
  let a={id:crypto.randomUUID(),name,category:$("#newCategory").value,description:"",status:"draft",updated:Date.now()};
  try{
    if(apiMode){
      const data=await NayaAPI.createApp({name,description:"",primaryColor:"#2563eb"});
      a={...data.application,category:a.category,updated:Date.now()};
    }
    apps.unshift(a);save();$("#modal").classList.add("hidden");$("#newName").value="";editingId=a.id;loadBuilder(a);showView("builder");toast(lang==="fr"?"Votre application a été créée.":"Your app has been created.");
  }catch(e){toast(e.message)}
}
$$(".nav").forEach(n=>n.addEventListener("click",()=>showView(n.dataset.view)));$$("[data-goto]").forEach(n=>n.addEventListener("click",()=>showView(n.dataset.goto)));
$("#newAppTop").onclick=openModal;$("#newAppList").onclick=openModal;$("#closeModal").onclick=()=>$("#modal").classList.add("hidden");$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")$("#modal").classList.add("hidden")});$("#createApp").onclick=createApp;$("#saveBuilder").onclick=saveBuilder;$("#saveBuilder2").onclick=saveBuilder;
["appName","welcomeTitle","welcomeText"].forEach(id=>$("#"+id).addEventListener("input",updatePreview));
$$(".swatch").forEach(b=>b.addEventListener("click",()=>{$$(".swatch").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");color=b.dataset.color;updatePreview()}));$("#customColor").addEventListener("input",e=>{color=e.target.value;updatePreview()});
$("#language").addEventListener("change",e=>{lang=e.target.value;document.documentElement.lang=lang;$$("[data-i18n]").forEach(el=>{let key=el.dataset.i18n;if(translations[lang][key])el.textContent=translations[lang][key]});renderApps();$("#crumbTitle").textContent=t($(".nav.active")?.dataset.view||"dashboard")});
renderApps();loadBuilder(apps[0]);

// Authentification et synchronisation avec l'API NAYAAPP.
function setAuthMode(mode){
  authMode=mode;
  $("#loginTab").classList.toggle("active",mode==="login");
  $("#registerTab").classList.toggle("active",mode==="register");
  $("#fullNameWrap").classList.toggle("hidden",mode!=="register");
  $("#orgNameWrap").classList.toggle("hidden",mode!=="register");
  $("#authTitle").textContent=mode==="login"?"Bienvenue sur NAYAAPP":"Créer votre espace NAYAAPP";
  $("#authIntro").textContent=mode==="login"?"Connectez-vous à votre espace de travail.":"Créez un compte et votre organisation.";
  $("#authSubmit").textContent=mode==="login"?"Se connecter":"Créer mon compte";
  $("#authPassword").autocomplete=mode==="login"?"current-password":"new-password";
  $("#authMessage").textContent="";
}
function showAuthenticated(){
  $("#authScreen").classList.add("hidden");
  $("#appShell").style.display="flex";
  const user=NayaAPI.user||{};
  const profileName=user.full_name||user.fullName||"Mon espace";
  const profile=document.querySelector(".profile span b");
  if(profile)profile.textContent=profileName;
  const status=$("#connectionStatus");if(status)status.textContent="Connecté à l'API";
}
function showUnauthenticated(message=""){
  $("#authScreen").classList.remove("hidden");
  $("#appShell").style.display="none";
  $("#authMessage").textContent=message;
}
async function loadRemoteApps(){
  const data=await NayaAPI.listApps();
  apps=data.applications.map(a=>({...a,category:"Application",updated:new Date(a.updated_at||a.created_at).getTime()}));
  apiMode=true;renderApps();
}
$("#loginTab").addEventListener("click",()=>setAuthMode("login"));
$("#registerTab").addEventListener("click",()=>setAuthMode("register"));
$("#authForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const message=$("#authMessage");message.textContent="Connexion en cours…";
  try{
    if(authMode==="register"){
      await NayaAPI.register({
        fullName:$("#authFullName").value.trim(),
        email:$("#authEmail").value.trim(),
        password:$("#authPassword").value,
        organizationName:$("#authOrgName").value.trim()
      });
    }else{
      await NayaAPI.login({email:$("#authEmail").value.trim(),password:$("#authPassword").value});
    }
    await loadRemoteApps();
    showAuthenticated();
    if(apps[0])loadBuilder(apps[0]);else loadBuilder(null);
    toast("Bienvenue sur NAYAAPP !");
  }catch(err){message.textContent=err.message}
});
$("#logoutBtn").addEventListener("click",()=>{
  NayaAPI.clearSession();apiMode=false;apps=[];renderApps();showUnauthenticated("Vous êtes déconnecté.");
});
(async function boot(){
  setAuthMode("login");
  try{
    await NayaAPI.health();
    $("#connectionStatus").textContent="API disponible";
    if(NayaAPI.token){
      await NayaAPI.me();
      await loadRemoteApps();
      showAuthenticated();
      if(apps[0])loadBuilder(apps[0]);else loadBuilder(null);
      return;
    }
    showUnauthenticated();
  }catch(err){
    $("#connectionStatus").textContent="API hors ligne";
    showUnauthenticated("Le serveur API n'est pas joignable. Démarrez-le puis rechargez cette page. "+err.message);
  }
})();
