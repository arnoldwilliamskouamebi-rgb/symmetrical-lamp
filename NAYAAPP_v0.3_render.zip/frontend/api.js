(() => {
  const base = window.NAYA_CONFIG.API_BASE_URL.replace(/\/$/, "");
  const TOKEN_KEY = "naya_token";
  const USER_KEY = "naya_user";

  async function request(path, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);
    const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
    if (token) headers.Authorization = `Bearer ${token}`;
    let response;
    try {
      response = await fetch(`${base}${path}`, { ...options, headers });
    } catch {
      throw new Error("API inaccessible. Vérifiez que le serveur NAYAAPP est démarré.");
    }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Erreur serveur (${response.status}).`);
    return data;
  }

  window.NayaAPI = {
    get token() { return localStorage.getItem(TOKEN_KEY); },
    get user() { try { return JSON.parse(localStorage.getItem(USER_KEY) || "null"); } catch { return null; } },
    setSession(data) {
      localStorage.setItem(TOKEN_KEY, data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(data.user || {}));
    },
    clearSession() {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    },
    async register(payload) {
      const data = await request("/auth/register", { method: "POST", body: JSON.stringify(payload) });
      this.setSession(data);
      return data;
    },
    async login(payload) {
      const data = await request("/auth/login", { method: "POST", body: JSON.stringify(payload) });
      this.setSession(data);
      return data;
    },
    async me() { return request("/auth/me"); },
    async listApps() { return request("/apps"); },
    async createApp(payload) {
      return request("/apps", { method: "POST", body: JSON.stringify(payload) });
    },
    async getApp(id) { return request(`/apps/${encodeURIComponent(id)}`); },
    async health() {
      const response = await fetch(base.replace(/\/api\/v1$/, "") + "/health");
      if (!response.ok) throw new Error("API indisponible");
      return response.json();
    }
  };
})();
