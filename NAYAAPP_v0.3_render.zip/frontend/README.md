# NAYAAPP — Prototype fonctionnel v0.1

## Ce que contient cette première livraison
- Tableau de bord responsive
- Création et liste d'applications de démonstration
- Constructeur avec aperçu mobile en direct
- Personnalisation de la couleur et du contenu d'accueil
- Interface français / anglais
- Sauvegarde locale dans le navigateur (localStorage)
- Première structure PWA (manifest)

## Lancer le prototype
1. Décompressez le dossier.
2. Ouvrez `index.html` dans un navigateur récent.
3. Pour tester l'installation PWA, servez le dossier via un serveur local HTTPS ou localhost.

Aucun compte réel ni backend n'est encore connecté. Les données restent dans le navigateur utilisé.

## Limites connues
Cette livraison est un prototype frontend, pas encore un SaaS multi-entreprise en production.
Il ne publie pas réellement d'applications sur Google Play ou l'App Store.
Les statistiques sont fictives et les interactions ne sont pas synchronisées entre appareils.

## Prochaine étape technique
1. API Node.js / Express avec authentification sécurisée.
2. PostgreSQL et séparation stricte des données par organisation.
3. Stockage cloud des médias.
4. Paiements et abonnements.
5. Notifications push.
6. Application mobile Flutter et publication Android / iOS.

## Structure
- index.html : interface
- styles.css : design responsive
- app.js : interactions et stockage local
- manifest.webmanifest : métadonnées PWA
